<?php
/* File with stationnames in Solomon Islands */

$country = 'Solomon Islands';

$icaos   = array(
  'AGGH' => 'Honiara / Henderson',
  'AGGM' => 'Munda',
  'AGGL' => 'Santa Cruz'
);

?>
