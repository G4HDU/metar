<?php
/* File with stationnames in Virgin Islands, U.S. */

$country = 'Virgin Islands, U.S.';

$icaos   = array(
  'TIST' => 'Charlotte Amalie, Cyril E. King International Airport, Saint Thomas'
);

?>
