<?php
/* File with stationnames in Kiribati */

$country = 'Kiribati';

$icaos   = array(
  'NGTR' => 'Arorae',
  'NGBR' => 'Beru',
  'NGTU' => 'Butaritari',
  'NGTA' => 'Tarawa'
);

?>
