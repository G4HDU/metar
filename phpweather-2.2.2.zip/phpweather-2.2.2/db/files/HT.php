<?php
/* File with stationnames in Haiti */

$country = 'Haiti';

$icaos   = array(
  'MTCH' => 'Cap-Haitien',
  'MTPP' => 'Port-Au-Prince / Aeroport International'
);

?>
