<?php
/* File with stationnames in Lebanon */

$country = 'Lebanon';

$icaos   = array(
  'OLBA' => 'Beyrouth Aeroport'
);

?>
