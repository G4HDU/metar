<?php
/* File with stationnames in Guadeloupe */

$country = 'Guadeloupe';

$icaos   = array(
  'TFFJ' => 'Gustavia, Saint Barthelemy',
  'TFFR' => 'Le Raizet, Guadeloupe'
);

?>
