<?php
/* File with stationnames in Tuvalu */

$country = 'Tuvalu';

$icaos   = array(
  'NGFU' => 'Funafuti',
  'NGFO' => 'Nanumea'
);

?>
