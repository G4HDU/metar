<?php
/* File with stationnames in Estonia */

$country = 'Estonia';

$icaos   = array(
  'EETN' => 'Tallinn'
);

?>
