<?php
/* File with stationnames in Korea, Democratic People's Republic of */

$country = 'Korea, Democratic People\'s Republic of';

$icaos   = array(
  'ZKKC' => 'Kimchaek',
  'ZKPY' => 'Pyongyang'
);

?>
