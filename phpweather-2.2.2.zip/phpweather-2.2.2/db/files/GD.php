<?php
/* File with stationnames in Grenada */

$country = 'Grenada';

$icaos   = array(
  'TGPY' => 'Point Salines Airport'
);

?>
