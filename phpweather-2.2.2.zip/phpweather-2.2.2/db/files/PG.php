<?php
/* File with stationnames in Papua New Guinea */

$country = 'Papua New Guinea';

$icaos   = array(
  'AYMD' => 'Madang',
  'AYPY' => 'Moresby',
  'AYWK' => 'Wewak'
);

?>
