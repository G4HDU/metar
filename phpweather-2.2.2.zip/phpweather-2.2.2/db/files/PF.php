<?php
/* File with stationnames in French Polynesia */

$country = 'French Polynesia';

$icaos   = array(
  'NTTB' => 'Bora-Bora',
  'NTTO' => 'Hao',
  'NTTX' => 'Mururoa',
  'NTTG' => 'Rangiroa / Tuamoto Island',
  'NTAA' => 'Tahiti-Faaa',
  'NTAT' => 'Tubuai'
);

?>
