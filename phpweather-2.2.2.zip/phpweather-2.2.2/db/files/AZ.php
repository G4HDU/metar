<?php
/* File with stationnames in Azerbaijan */

$country = 'Azerbaijan';

$icaos   = array(
  'UBBB' => 'Baku / Bine Airport'
);

?>
