<?php
/* File with stationnames in Puerto Rico */

$country = 'Puerto Rico';

$icaos   = array(
  'TJBQ' => 'Aquadilla / Borinquen',
  'TISX' => 'Christiansted / Alex. Hamilton Field, Saint Croix',
  'TJSJ' => 'Luis Munoz Marin',
  'TJMZ' => 'Mayaguez / Eugenio',
  'TJPS' => 'Ponce / Mercedita'
);

?>
