<?php
/* File with stationnames in Ecuador */

$country = 'Ecuador';

$icaos   = array(
  'SEAM' => 'Ambato / Chachoan',
  'SEBC' => 'Bahia De Caraquez',
  'SELO' => 'Catamayo / Camilo Ponce Enriquez',
  'SECU' => 'Cuenca / Mariscal Lamar',
  'SEES' => 'Esmeraldas-Tachina',
  'SEGU' => 'Guayaquil / Simon Bolivar',
  'SEIB' => 'Ibarra / Atahualpa',
  'SELT' => 'Latacunga',
  'SEMA' => 'Macara / J. M. Velasco I.',
  'SEMH' => 'Machala / General M. Serrano',
  'SEMT' => 'Manta',
  'SEPA' => 'Pastaza / Rio Amazonas',
  'SEQU' => 'Quito / Mariscal Sucre',
  'SESA' => 'Salinas / General Ulpiano Paez',
  'SEST' => 'San Cristobal Galapagos',
  'SETI' => 'Tiputini',
  'SETU' => 'Tulcan / El Rosal'
);

?>
