<?php
/* File with stationnames in Switzerland */

$country = 'Switzerland';

$icaos   = array(
  'LSZB' => 'Bern / Belp',
  'LSGG' => 'Geneve-Cointrin',
  'LSZG' => 'Grenchen',
  'LSGL' => 'Lausanne',
  'LSZA' => 'Lugano',
  'LSGN' => 'Neuchatel',
  'LSMP' => 'Payerne',
  'LSZR' => 'Saint Gallen-Altenrhein',
  'LSGS' => 'Sion',
  'LSZH' => 'Zurich-Kloten'
);

?>
