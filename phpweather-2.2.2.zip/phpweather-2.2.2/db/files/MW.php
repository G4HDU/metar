<?php
/* File with stationnames in Malawi */

$country = 'Malawi';

$icaos   = array(
  'FWCL' => 'Chileka',
  'FWCT' => 'Chitipa',
  'FWDZ' => 'Dedza',
  'FWKA' => 'Karonga',
  'FWKI' => 'Lilongwe International Airport',
  'FWMG' => 'Mangochi',
  'FWMY' => 'Monkey Bay',
  'FWMZ' => 'Mzimba',
  'FWUU' => 'Mzuzu',
  'FWKK' => 'Nkhota Kota',
  'FWSM' => 'Salima'
);

?>
