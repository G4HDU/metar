<?php
/* File with stationnames in Taiwan */

$country = 'Taiwan';

$icaos   = array(
  'RCFS' => 'Chia Tung',
  'RCTP' => 'Chiang Kai Shek',
  'RCKU' => 'Chiayi Tw-Afb',
  'RCQS' => 'Chihhang Tw-Afb',
  'RCBS' => 'Chinmem / Shatou Air Force Base',
  'RCLM' => 'Dongsha',
  'RCNO' => 'Dongshi',
  'RCFN' => 'Feng Nin Tw-Afb',
  'RCKW' => 'Hengchun',
  'RCPO' => 'Hsinchu Tw-Afb',
  'RCYU' => 'Hulien Ab',
  'RCMS' => 'Ilan',
  'RCAY' => 'Kangshan Tw-Afb',
  'RCKH' => 'Kaohsiung International Airport',
  'RCQC' => 'Makung Ab',
  'RCFG' => 'Mazu',
  'RCUK' => 'Pa Kuei / Bakuai',
  'RCSQ' => 'Pingtung North Air Force Base',
  'RCDC' => 'Pingtung South Air Force Base',
  'RCSS' => 'Sungshan / Taipei',
  'RCLG' => 'Taichung Tw-Afb',
  'RCNN' => 'Tainan Tw-Afb',
  'RCGM' => 'Taoyuan Ab = 589650',
  'RCMQ' => 'Wuchia Observatory'
);

?>
