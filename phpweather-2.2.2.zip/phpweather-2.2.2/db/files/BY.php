<?php
/* File with stationnames in Belarus */

$country = 'Belarus';

$icaos   = array(
  'UMMS' => 'Minsk',
  'EVRA' => 'Riga Airport',
  'UMII' => 'Vitebsk'
);

?>
