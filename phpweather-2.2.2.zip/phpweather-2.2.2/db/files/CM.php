<?php
/* File with stationnames in Cameroon */

$country = 'Cameroon';

$icaos   = array(
  'FKAG' => 'Abong-Mbang',
  'FKAF' => 'Bafia',
  'FKKV' => 'Bamenda',
  'FKAB' => 'Banyo',
  'FKKI' => 'Batouri',
  'FKAO' => 'Betare-Oya',
  'FKKD' => 'Douala Obs.',
  'FKKR' => 'Garoua',
  'FKKM' => 'Koundja',
  'FKKB' => 'Kribi',
  'FKAL' => 'Lomie',
  'FKKF' => 'Mamfe',
  'FKKA' => 'Maroua-Salak',
  'FKAM' => 'Meiganga',
  'FKKN' => 'Ngaoundere',
  'FKAN' => 'Nkongsamba',
  'FKKC' => 'Tiko',
  'FKYS' => 'Yaounde',
  'FKAY' => 'Yoko'
);

?>
