<?php
/* File with stationnames in Central African Republic */

$country = 'Central African Republic';

$icaos   = array(
  'FEFA' => 'Alindao',
  'FEFM' => 'Bambari',
  'FEFG' => 'Bangassou',
  'FEFF' => 'Bangui',
  'FEFT' => 'Berberati',
  'FEFI' => 'Birao',
  'FEFS' => 'Bossangoa',
  'FEFL' => 'Bossembele',
  'FEFO' => 'Bouar',
  'FEFR' => 'Bria',
  'FEFN' => 'N\'Dele',
  'FEFB' => 'Obo',
  'FEFY' => 'Yalinga'
);

?>
