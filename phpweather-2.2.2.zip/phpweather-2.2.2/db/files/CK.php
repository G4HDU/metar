<?php
/* File with stationnames in Cook Islands */

$country = 'Cook Islands';

$icaos   = array(
  'NIUE' => 'Alofi / Niue',
  'NCRG' => 'Rarotonga'
);

?>
