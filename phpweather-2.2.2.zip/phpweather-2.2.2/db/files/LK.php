<?php
/* File with stationnames in Sri Lanka */

$country = 'Sri Lanka';

$icaos   = array(
  'VCCA' => 'Anuradhapura',
  'VCCB' => 'Batticaloa',
  'VCBI' => 'Katunayake',
  'VCCC' => 'Ratmalana',
  'VCCT' => 'Trincomalee'
);

?>
