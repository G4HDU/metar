<?php
/* File with stationnames in Uzbekistan */

$country = 'Uzbekistan';

$icaos   = array(
  'UTED' => 'Dzizak',
  'UTSS' => 'Samarkand',
  'UTSM' => 'Tamdy',
  'UTTT' => 'Tashkent',
  'UTST' => 'Termez'
);

?>
