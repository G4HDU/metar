<?php
/* File with stationnames in Peru */

$country = 'Peru';

$icaos   = array(
  'SPHY' => 'Andahuayla',
  'SPHZ' => 'Anta Huaraz',
  'SPQU' => 'Arequipa',
  'SPAY' => 'Atalaya',
  'SPHO' => 'Ayacucho',
  'SPJR' => 'Cajamarca',
  'SPPY' => 'Chachapoyas',
  'SPHI' => 'Chiclayo',
  'SPEO' => 'Chimbote',
  'SPZO' => 'Cuzco',
  'SPNC' => 'Huanuco',
  'SPQT' => 'Iquitos',
  'SPJI' => 'Juanjui',
  'SPJL' => 'Juliaca',
  'SPIM' => 'Lima-Callao / Aerop. Internacional Jorgechavez',
  'SPSO' => 'Pisco',
  'SPUR' => 'Piura',
  'SPCL' => 'Pucallpa',
  'SPTU' => 'Puerto Maldonado',
  'SPJA' => 'Rioja',
  'SPJN' => 'San Juan',
  'SPTN' => 'Tacna',
  'SPYL' => 'Talara',
  'SPST' => 'Tarapoto',
  'SPGM' => 'Tingo Maria',
  'SPRU' => 'Trujillo',
  'SPME' => 'Tumbes',
  'SPMS' => 'Yurimaguas'
);

?>
