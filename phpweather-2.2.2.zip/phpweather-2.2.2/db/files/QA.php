<?php
/* File with stationnames in Qatar */

$country = 'Qatar';

$icaos   = array(
  'OTBD' => 'Doha International Airport'
);

?>
