<?php
/* File with stationnames in Israel */

$country = 'Israel';

$icaos   = array(
  'LLBS' => 'Beer-Sheva',
  'LLBG' => 'Ben-Gurion International Airport',
  'LLET' => 'Eilat',
  'LLOV' => 'Ovda',
  'LLHA' => 'Sde-Haifa Haifa'
);

?>
