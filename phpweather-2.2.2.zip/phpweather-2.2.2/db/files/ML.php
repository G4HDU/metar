<?php
/* File with stationnames in Mali */

$country = 'Mali';

$icaos   = array(
  'GABS' => 'Bamako / Senou',
  'GABG' => 'Bougouni',
  'GAGO' => 'Gao',
  'GAHB' => 'Hombori',
  'GAKY' => 'Kayes',
  'GAKA' => 'Kenieba',
  'GAKL' => 'Kidal',
  'GAKT' => 'Kita',
  'GAKO' => 'Koutiala',
  'GAMK' => 'Menaka',
  'GAMB' => 'Mopti',
  'GANK' => 'Nara',
  'GANR' => 'Nioro Du Sahel',
  'GASN' => 'San',
  'GASG' => 'Segou',
  'GASK' => 'Sikasso',
  'GATS' => 'Tessalit',
  'GATB' => 'Tombouctou'
);

?>
