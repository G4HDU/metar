<?php
/* File with stationnames in Malaysia */

$country = 'Malaysia';

$icaos   = array(
  'WBGB' => 'Bintulu',
  'WMKJ' => 'Johore Bharu / Senai',
  'WMKC' => 'Kota Bharu',
  'WBKK' => 'Kota Kinabalu',
  'WMKK' => 'Kuala Lumpur / Subang',
  'WMKD' => 'Kuantan',
  'WBGG' => 'Kuching',
  'WBKT' => 'Kudat',
  'WBKL' => 'Labuan',
  'WMKL' => 'Langkawi',
  'WMKM' => 'Malacca',
  'WBGR' => 'Miri',
  'WMKP' => 'Penang / Bayan Lepas',
  'WBKS' => 'Sandakan',
  'WBGS' => 'Sibu',
  'WMBA' => 'Sitiawan',
  'WBKW' => 'Tawau'
);

?>
