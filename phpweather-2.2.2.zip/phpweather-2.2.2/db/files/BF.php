<?php
/* File with stationnames in Burkina Faso */

$country = 'Burkina Faso';

$icaos   = array(
  'DFOO' => 'Bobo-Dioulasso',
  'DFCO' => 'Boromo',
  'DFOD' => 'Dedougou',
  'DFEE' => 'Dori',
  'DFEF' => 'Fada N\'Gourma',
  'DFOG' => 'Gaoua',
  'DFFD' => 'Ouagadougou',
  'DFCC' => 'Ouahigouya',
  'DFCP' => 'Po'
);

?>
