<?php
/* File with stationnames in British Indian Ocean Territory */

$country = 'British Indian Ocean Territory';

$icaos   = array(
  'FJDG' => 'Diego Garcia'
);

?>
