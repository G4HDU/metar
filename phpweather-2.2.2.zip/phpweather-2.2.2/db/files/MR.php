<?php
/* File with stationnames in Mauritania */

$country = 'Mauritania';

$icaos   = array(
  'GQNA' => 'Aioun El Atrouss',
  'GQNJ' => 'Akjoujt',
  'GQPA' => 'Atar',
  'GQPT' => 'Bir Moghrein',
  'GQNB' => 'Boutilimit',
  'GQNK' => 'Kaedi',
  'GQNF' => 'Kiffa',
  'GQNI' => 'Nema',
  'GQPP' => 'Nouadhibou',
  'GQNN' => 'Nouakchott',
  'GQNR' => 'Rosso',
  'GQND' => 'Tidjikja'
);

?>
