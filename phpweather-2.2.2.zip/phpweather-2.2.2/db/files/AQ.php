<?php
/* File with stationnames in Antarctica */

$country = 'Antarctica';

$icaos   = array(
  'NZSP' => 'Amundsen-Scott South Pole Statio',
  'UATA' => 'Aralskoe More',
  'RCMJ' => 'Donggang',
  'UAOO' => 'Kzyl-Orda',
  'RCLY' => 'Lan Yu',
  'UAII' => 'Shymkent',
  'NZCM' => 'Williams Field'
);

?>
