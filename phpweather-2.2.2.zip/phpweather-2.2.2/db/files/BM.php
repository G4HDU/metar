<?php
/* File with stationnames in Bermuda */

$country = 'Bermuda';

$icaos   = array(
  'TXKF' => 'Bermuda'
);

?>
