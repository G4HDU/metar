<?php
/* File with stationnames in Armenia */

$country = 'Armenia';

$icaos   = array(
  'UGEE' => 'Yerevan'
);

?>
