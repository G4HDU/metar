<?php
/* File with stationnames in Aruba */

$country = 'Aruba';

$icaos   = array(
  'TNCA' => 'Queen Beatrix Airport, Aruba'
);

?>
