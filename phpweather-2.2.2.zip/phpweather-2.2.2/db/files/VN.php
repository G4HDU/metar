<?php
/* File with stationnames in Viet Nam */

$country = 'Viet Nam';

$icaos   = array(
  'VVDN' => 'Da Nang',
  'VVNB' => 'Ha Noi',
  'VVTS' => 'Ho Chi Minh',
  'VVPB' => 'Hue',
  'VVNT' => 'Nha Trang',
  'VVPK' => 'Pleiku City',
  'VVQN' => 'Quy Nhon',
  'VVVH' => 'Vinh'
);

?>
