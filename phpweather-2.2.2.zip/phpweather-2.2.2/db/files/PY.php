<?php
/* File with stationnames in Paraguay */

$country = 'Paraguay';

$icaos   = array(
  'SGES' => 'Aeropuerto Guarany',
  'SGAS' => 'Asuncion / Aeropuerto',
  'SGCO' => 'Concepcion',
  'SGEN' => 'Encarnacion',
  'SGME' => 'Mariscal Estigarribia',
  'SGNA' => 'Nueva Asuncion'
);

?>
