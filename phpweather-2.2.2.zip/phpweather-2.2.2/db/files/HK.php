<?php
/* File with stationnames in Hong Kong */

$country = 'Hong Kong';

$icaos   = array(
  'VHCH' => 'Cheung Chau',
  'VHHH' => 'Hong Kong Inter-National Airport'
);

?>
