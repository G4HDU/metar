<?php
/* File with stationnames in Tajikistan */

$country = 'Tajikistan';

$icaos   = array(
  'UTDD' => 'Dushanbe'
);

?>
