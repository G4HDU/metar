<?php
/* File with stationnames in Guinea-Bissau */

$country = 'Guinea-Bissau';

$icaos   = array(
  'GGBF' => 'Bafata',
  'GGOV' => 'Bissau Aeroport'
);

?>
