<?php
/* File with stationnames in Libyan Arab Jamahiriya */

$country = 'Libyan Arab Jamahiriya';

$icaos   = array(
  'HLLB' => 'Benina',
  'HLTD' => 'Ghadames',
  'HLGT' => 'Ghat',
  'HLKF' => 'Kufra',
  'HLLS' => 'Sebha',
  'HLLT' => 'Tripoli Inter-National Airport'
);

?>
