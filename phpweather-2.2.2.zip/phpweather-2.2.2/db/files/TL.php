<?php
/* File with stationnames in East Timor */

$country = 'East Timor';

$icaos   = array(
  'WPEC' => 'Baucau',
  'WPDL' => 'Dilli / Dilli Airport',
  'WPOC' => 'Oe-Cusse / Oe Cusse'
);

?>
