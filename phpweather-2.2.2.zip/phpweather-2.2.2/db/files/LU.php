<?php
/* File with stationnames in Luxembourg */

$country = 'Luxembourg';

$icaos   = array(
  'ELLX' => 'Luxembourg / Luxembourg'
);

?>
