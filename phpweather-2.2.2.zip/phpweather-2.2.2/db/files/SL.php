<?php
/* File with stationnames in Sierra Leone */

$country = 'Sierra Leone';

$icaos   = array(
  'GFLL' => 'Lungi'
);

?>
