<?php
/* File with stationnames in Kuwait */

$country = 'Kuwait';

$icaos   = array(
  'OKBK' => 'Kuwait International airport'
);

?>
