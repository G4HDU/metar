<?php
/* File with stationnames in Reunion */

$country = 'Reunion';

$icaos   = array(
  'FMEE' => 'Saint-Denis / Gillot',
  'FMEP' => 'Saint-Pierre'
);

?>
