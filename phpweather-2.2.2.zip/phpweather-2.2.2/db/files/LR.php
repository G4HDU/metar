<?php
/* File with stationnames in Liberia */

$country = 'Liberia';

$icaos   = array(
  'GLRB' => 'Grand Bassa, Roberts Field'
);

?>
