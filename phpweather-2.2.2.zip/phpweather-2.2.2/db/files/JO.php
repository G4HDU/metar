<?php
/* File with stationnames in Jordan */

$country = 'Jordan';

$icaos   = array(
  'OJAM' => 'Amman Airport',
  'OJAQ' => 'Aqaba Airport',
  'OJHR' => 'H-4\'Irwaished',
  'OJHF' => 'H-5\'Safawi',
  'OJBD' => 'Irbid',
  'LLJR' => 'Jerusalem Airport',
  'OJMN' => 'Ma\'An',
  'OJMF' => 'Mafraq',
  'OJAI' => 'Queen Alia Airport'
);

?>
