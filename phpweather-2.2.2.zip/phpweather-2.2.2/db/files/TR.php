<?php
/* File with stationnames in Turkey */

$country = 'Turkey';

$icaos   = array(
  'LTAG' => 'Adana / Incirlik',
  'LTAF' => 'Adana / Sakirpasa',
  'LTAH' => 'Afyon',
  'LTBT' => 'Akhisar',
  'LTAC' => 'Ankara / Esenboga',
  'LTAD' => 'Ankara / Etimesgut',
  'LTAI' => 'Antalya',
  'LTBD' => 'Aydin',
  'LTBF' => 'Balikesir',
  'LTBG' => 'Bandirma',
  'LTCJ' => 'Batman',
  'LTBV' => 'Bodrum',
  'LTBE' => 'Bursa',
  'LTBH' => 'Canakkale',
  'LTBU' => 'Corlu',
  'LTBS' => 'Dalaman',
  'LTCC' => 'Diyarbakir',
  'LTCA' => 'Elazig',
  'LTCD' => 'Erzincan',
  'LTCE' => 'Erzurum',
  'LTBI' => 'Eskisehir',
  'LTAJ' => 'Gaziantep',
  'LTAK' => 'Iskenderun',
  'LTBM' => 'Isparta',
  'LTBA' => 'Istanbul / Ataturk',
  'LTBJ' => 'Izmir / Adnan Menderes',
  'LTBL' => 'Izmir / Cigli',
  'LTCF' => 'Kars',
  'LTAU' => 'Kayseri / Erkilet',
  'LTAN' => 'Konya',
  'LTAT' => 'Malatya / Erhac',
  'LTAP' => 'Merzifon',
  'LTAE' => 'Murted Tur-Afb',
  'LTCK' => 'Mus Tur-Afb',
  'LTAQ' => 'Samsun',
  'LTAR' => 'Sivas',
  'LTAV' => 'Sivrihisar',
  'LTAW' => 'Tokat',
  'LTBQ' => 'Topel Tur-Afb',
  'LTCG' => 'Trabzon',
  'LTCH' => 'Urfa',
  'LTBO' => 'Usak',
  'LTCI' => 'Van',
  'LTAS' => 'Zonguldak'
);

?>
