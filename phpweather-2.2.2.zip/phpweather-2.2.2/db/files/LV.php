<?php
/* File with stationnames in Latvia */

$country = 'Latvia';

$icaos   = array(
  'UMRR' => 'Riga',
  'UMRW' => 'Ventspils'
);

?>
