<?php
/* File with stationnames in Virgin Islands, British */

$country = 'Virgin Islands, British';

$icaos   = array(
  'TUPJ' => 'Beef Island, Tortola'
);

?>
