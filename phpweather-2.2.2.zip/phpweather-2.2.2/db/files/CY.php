<?php
/* File with stationnames in Cyprus */

$country = 'Cyprus';

$icaos   = array(
  'LCRA' => 'Akrotiri',
  'LCNC' => 'Athalassa',
  'LCEN' => 'Ercan',
  'LCLK' => 'Larnaca Airport',
  'LCPH' => 'Paphos Airport'
);

?>
