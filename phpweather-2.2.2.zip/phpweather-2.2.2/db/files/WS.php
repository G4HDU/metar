<?php
/* File with stationnames in Samoa */

$country = 'Samoa';

$icaos   = array(
  'NSAP' => 'Apia / Upolu Island',
  'NSFA' => 'Faleolo Intl / Apia'
);

?>
