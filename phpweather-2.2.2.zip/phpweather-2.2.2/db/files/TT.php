<?php
/* File with stationnames in Trinidad and Tobago */

$country = 'Trinidad and Tobago';

$icaos   = array(
  'TTPT' => 'Crown Point Airport, Tobago',
  'TTCP' => 'Crown Pt./ Scarborou',
  'TTPP' => 'Piarco International Airport, Trinidad'
);

?>
