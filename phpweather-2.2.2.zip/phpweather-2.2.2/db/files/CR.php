<?php
/* File with stationnames in Costa Rica */

$country = 'Costa Rica';

$icaos   = array(
  'MRCH' => 'Chacarita',
  'MROC' => 'Juan Santamaria',
  'MRLB' => 'Liberia',
  'MRNC' => 'Nicoya',
  'MRPM' => 'Palmar Sur',
  'MRLM' => 'Puerto Limon',
  'MRPV' => 'Tobias Bolanos International'
);

?>
