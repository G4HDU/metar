<?php
/* File with stationnames in Togo */

$country = 'Togo';

$icaos   = array(
  'DXAK' => 'Atakpame',
  'DXXX' => 'Lome',
  'DXMG' => 'Mango',
  'DXNG' => 'Niamtougou',
  'DXSK' => 'Sokode',
  'DXTA' => 'Tabligbo'
);

?>
