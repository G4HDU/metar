<?php
/* File with stationnames in Bulgaria */

$country = 'Bulgaria';

$icaos   = array(
  'LBBG' => 'Burgas',
  'LBPD' => 'Plovdiv',
  'LBRS' => 'Rousse',
  'LBSF' => 'Sofia Observ.',
  'LBWN' => 'Varna'
);

?>
