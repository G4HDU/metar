<?php
/* File with stationnames in Panama */

$country = 'Panama';

$icaos   = array(
  'MPBO' => 'Bocas Del Toro International',
  'MPDA' => 'David',
  'MPFS' => 'Ft Sherman Rocob',
  'MPHO' => 'Howard Air Force Base',
  'MPMG' => 'Marcos A. Gelabert',
  'MPSA' => 'Santiago',
  'MPTO' => 'Tocumen'
);

?>
