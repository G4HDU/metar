<?php
/* File with stationnames in Uganda */

$country = 'Uganda';

$icaos   = array(
  'HUAR' => 'Arua',
  'HUEN' => 'Entebbe Airport',
  'HUGU' => 'Gulu',
  'HUJI' => 'Jinja',
  'HUKB' => 'Kabale',
  'HUKS' => 'Kasese',
  'HUMI' => 'Masindi',
  'HUMA' => 'Mbarara',
  'HUSO' => 'Soroti',
  'HUTO' => 'Tororo'
);

?>
