<?php
/* File with stationnames in Iraq */

$country = 'Iraq';

$icaos   = array(
  'ORBB' => 'Baghdad',
  'ORBM' => 'Mosul',
  'ORMS' => 'Shaibah / Basrah'
);

?>
