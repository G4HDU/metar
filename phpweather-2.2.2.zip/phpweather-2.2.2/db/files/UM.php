<?php
/* File with stationnames in United States Minor Outlying Islands */

$country = 'United States Minor Outlying Islands';

$icaos   = array(
  'PGUM' => 'Agana, Guam, Mariana Islands',
  'PGUA' => 'Andersen Air Force Base',
  'PGAC' => 'Guam, Mariana Island',
  'PJON' => 'Johnston Island',
  'NSTU' => 'Pago Pago / Int. Airp.',
  'PGWT' => 'Peipeinimaru',
  'PGRO' => 'Rota Intl / Rota Island',
  'PGSN' => 'Saipan / Isley Coast Guard Station',
  'PWAK' => 'Wake Island Airfld'
);

?>
