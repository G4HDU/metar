<?php
/* File with stationnames in Ghana */

$country = 'Ghana';

$icaos   = array(
  'DGAA' => 'Accra',
  'DGAD' => 'Ada',
  'DGKA' => 'Akim Oda',
  'DGAK' => 'Akuse',
  'DGTX' => 'Axim',
  'DGLB' => 'Bole',
  'DGAH' => 'Ho',
  'DGKK' => 'Koforidua',
  'DGSI' => 'Kumasi',
  'DGLN' => 'Navrongo',
  'DGAS' => 'Saltpond',
  'DGSB' => 'Sefwi Bekwai',
  'DGSN' => 'Sunyani',
  'DGTK' => 'Takoradi',
  'DGLE' => 'Tamale',
  'DGAT' => 'Tema',
  'DGLW' => 'Wa',
  'DGSW' => 'Wenchi',
  'DGLY' => 'Yendi'
);

?>
