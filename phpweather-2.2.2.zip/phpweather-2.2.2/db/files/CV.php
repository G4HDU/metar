<?php
/* File with stationnames in Cape Verde */

$country = 'Cape Verde';

$icaos   = array(
  'GVAC' => 'Sal'
);

?>
