<?php
/* File with stationnames in Pakistan */

$country = 'Pakistan';

$icaos   = array(
  'OPDI' => 'Dera Ismail Khan',
  'OPKD' => 'Hyderabad Airport',
  'OPRN' => 'Islamabad Airport',
  'OPJA' => 'Jacobabad',
  'OPJI' => 'Jiwani',
  'OPKC' => 'Karachi Airport',
  'OPLA' => 'Lahore Airport',
  'OPLH' => 'Lahore City',
  'OPMI' => 'Mianwali',
  'OPMT' => 'Multan',
  'OPNH' => 'Nawabshah',
  'OPPG' => 'Panjgur',
  'OPPS' => 'Peshawar',
  'OPQT' => 'Quetta Airport',
  'OPRS' => 'Risalpur',
  'OPSR' => 'Sargodha',
  'OPSB' => 'Sibi'
);

?>
