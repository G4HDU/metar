<?php
/* File with stationnames in Micronesia, Federated States of */

$country = 'Micronesia, Federated States of';

$icaos   = array(
  'PTTK' => 'Kosrae Carolines / V',
  'PTSA' => 'Kusaie / Kosrae East',
  'PTPN' => 'Ponape Island',
  'PTKK' => 'Truk Intl / Moen Island',
  'PTYA' => 'Yap Island'
);

?>
