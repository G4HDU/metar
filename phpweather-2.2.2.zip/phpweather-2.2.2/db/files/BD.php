<?php
/* File with stationnames in Bangladesh */

$country = 'Bangladesh';

$icaos   = array(
  'VGEG' => 'Chittagong Patenga',
  'VGCB' => 'Cox\'s Bazar',
  'VGTJ' => 'Dhaka',
  'VGIS' => 'Ishurdi',
  'VGJR' => 'Jessore',
  'VGZR' => 'Kurmitola, Dia',
  'VGRJ' => 'Rajshahi',
  'VGSY' => 'Sylhet'
);

?>
